from django.apps import AppConfig


class CategorieConfig(AppConfig):
    name = 'categorie'
